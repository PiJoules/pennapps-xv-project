from convert2d import getBinaryEdges
from knn import knn
from original_2d_convertion import convert_original_2D

filename='C:\Users\Bineeta\Desktop\Final Code\1.png'
directory_path='C:\Users\Bineeta\Desktop\Final Code\\training1'
training=convert_original_2D(directory_path)  # dict[str, arr]

# Convert mapping to lst
training_vec = zip(*training)  # list[tuple[str, arr]]

test=getBinaryEdges(filename)  # 2d arr
results = knn(map(lambda x: x[1], training_vec), test, 3)  # list[tuple[int, 2d arr]]

best_results = []
for i, img in results:
	best_results.append(training_vec[i])

print(map(lambda x: x[0], best_results))

